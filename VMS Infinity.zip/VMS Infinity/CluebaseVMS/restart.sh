docker-compose down 2>&1 | grep -v "variable"
docker-compose up -d 2>&1 | grep -v "variable"