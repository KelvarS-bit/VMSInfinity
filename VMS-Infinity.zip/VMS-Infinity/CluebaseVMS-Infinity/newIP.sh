ip_address=`hostname -I | awk '{ print $1 }'`
sed -i "/^MACHINE_HOST=/s/[^=]*$/${ip_address}/;/^APP_HOST=/s/[^=]*$/${ip_address}/;/^LOCAL_HOST=/s/[^=]*$/${ip_address}/" .env
