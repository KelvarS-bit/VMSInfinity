#!/bin/bash

env_file_path="${PWD}/.env"

if cat "${env_file_path}" | grep "CONF_PATH" > /dev/null; then
  grep -v "CONF_PATH" "${env_file_path}" > tmpfile && mv tmpfile .env
fi

last_line=$(tail -n 1 "$env_file_path")

if [ ! -z "$last_line" ]; then
   echo "\n" >> "${env_file_path}"
fi

echo "CONF_PATH=${PWD}" >> "${env_file_path}"