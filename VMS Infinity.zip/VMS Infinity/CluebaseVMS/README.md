# stop docker
docker-compose down

# update docker
docker-compose pull

# run docker
docker-compose up -d
